#include "WProgram.h"











int ledPin = 13 ; 
int knockSensor = 0 ; 
byte val = 0 ; 
int statePin = LOW ; 
int THRESHOLD = 150 ; 

void setup ( ) { 
	pinMode ( ledPin , OUTPUT ) ; 
	beginSerial ( 9600 ) ; 
} 

void loop ( ) { 
	val = analogRead ( knockSensor ) ; 
	printInteger ( val ) ; 
	printByte ( 10 ) ; 
	printByte ( 13 ) ; 
	if ( val >= THRESHOLD ) { 
		statePin = ! statePin ; 
		digitalWrite ( ledPin , statePin ) ; 
		printString ( "Knock!" ) ; 
		printByte ( 10 ) ; 
		printByte ( 13 ) ; 
	} 
	delay ( 100 ) ; 
} 
