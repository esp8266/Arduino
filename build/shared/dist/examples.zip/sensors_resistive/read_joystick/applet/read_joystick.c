#include "WProgram.h"















int ledPin = 13 ; 
int joyPin1 = 0 ; 
int joyPin2 = 1 ; 
int value1 = 0 ; 
int value2 = 0 ; 

void setup ( ) 
{ 
	pinMode ( ledPin , OUTPUT ) ; 
	beginSerial ( 9600 ) ; 
} 

int treatValue ( int data ) 
{ 
	return ( data * 9 / 1024 ) + 48 ; 
} 

void loop ( ) 
{ 
	value1 = analogRead ( joyPin1 ) ; 
	delay ( 100 ) ; 
	
	value2 = analogRead ( joyPin2 ) ; 
	
	digitalWrite ( ledPin , HIGH ) ; 
	delay ( value1 / 4 ) ; 
	digitalWrite ( ledPin , LOW ) ; 
	delay ( value2 / 4 ) ; 
	serialWrite ( 'J' ) ; 
	serialWrite ( treatValue ( value1 ) ) ; 
	serialWrite ( treatValue ( value2 ) ) ; 
	serialWrite ( 10 ) ; 
	serialWrite ( 13 ) ; 
} 
