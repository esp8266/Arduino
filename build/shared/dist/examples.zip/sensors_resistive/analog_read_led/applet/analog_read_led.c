#include "WProgram.h"














int potPin1 = 0 ; 
int potPin2 = 1 ; 
int ledPin = 9 ; 
int soundPin = 10 ; 
int val1 = 0 ; 
int val2 = 0 ; 
int timecount = 0 ; 

void setup ( ) { 
	pinMode ( ledPin , OUTPUT ) ; 
	pinMode ( soundPin , OUTPUT ) ; 
} 

void loop ( ) { 
	
	val1 = analogRead ( potPin1 ) ; 
	analogWrite ( ledPin , val1 / 4 ) ; 
	

	val2 = analogRead ( potPin2 ) ; 
	


	if ( timecount >= val2 / 2 ) { 
		int count = 0 ; 
		for ( count = 0 ; count <= 10 ; count ++ ) { 
			digitalWrite ( soundPin , HIGH ) ; 
			delayMicroseconds ( 1135 ) ; 
			digitalWrite ( soundPin , LOW ) ; 
			delayMicroseconds ( 1135 ) ; 
		} 
		timecount = 0 ; 
	} 
	timecount ++ ; 
} 
