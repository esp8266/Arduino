#!/bin/sh

# Anti-Web Restarting Shell Script 
# (C) 2001-2004 Hardcore Software

# This shell script is useful for updating the copyright
# dates for AW and, well, any other project.


for TP in `ls` ; do
  sed 's/2003/2004/' $TP > __temp_file;
  mv __temp_file $TP;
done
