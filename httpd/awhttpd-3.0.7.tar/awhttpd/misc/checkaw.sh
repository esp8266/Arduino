#!/bin/sh

# Anti-Web Restarting Shell Script 
# (C) 2001-2004 Hardcore Software

# This shell script is designed to be run by your cron daemon at
# intervals of your choosing. Basically, it will check to see if
# Anti-Web is still running. If it is, it will do nothing. If it
# isn't, it will relaunch Anti-Web. Although I've never experienced
# any problems with AW crashing, it's always better safe than sorry.


# Please read, and adjust if necessary, all variables below if necessary
# for your particular configuration.

# The absolute location of the awhttpd binary.
AWBINLOC=/home/doug/devel/aw3/awhttpd
# The path to the root of your webpage.
AWDIR=/home/doug/devel/aw3/test/



A_PORT=`grep '^listen' $AWDIR/awhttpd.conf | head -n 1 | awk '{print $2}'`

if netstat -an | grep $A_PORT | grep LISTEN > /dev/null; then
  echo > /dev/null;
else 
  if $AWBINLOC $AWDIR > /dev/null 2> /dev/null; then
    logger -t AWHTTPD Restarted Anti-Web;
  else
    logger -t AWHTTPD Unable to restart Anti-Web!;
  fi
fi
