#!/usr/local/bin/php

<html>
<title>hcsw.org's PHP calculator</title>

<body>

<h1>hcsw.org's PHP calculator</h1>

<br><br>

<?
  $x =  $_GET["x"];
  $y =  $_GET["y"];
  $operator = $_GET["operator"];
?>

<form method="GET" action="math.php">
  Enter numbers and select operator
  <input type=text name=x value="<? echo $x ?>">

  <select name=operator value="<?echo $operator?>">
    <option <? if ($operator == "+") echo "selected" ?>>+
    <option <? if ($operator == "-") echo "selected" ?>>-
    <option value="*" <? if ($operator == "*") echo "selected" ?>>&times;
    <option value="/" <? if ($operator == "/") echo "selected" ?>>&divide;
  </select>

  <input type=text name=y value="<? echo $y ?>">

  <input type=submit value="Calculate now">

</form>

<br><br>

<?

        switch($operator)
        {
                case "+" :
                        $val = $x + $y;
                        $ops = "+";
                        break;
                case "-" :
                        $val = $x - $y;
                        $ops = "-";
                        break;
                case "*" :
                        $val = $x * $y;
                        $ops = "�";
                        break;
                case "/" :
                        $val = $x / $y;
                        $ops = "�";
                        break;
        }
        if ($operator != "")
          printf("<pre>%d %s %d = %d</pre>",$x,$ops,$y,$val);
?>


</body>
</html>
