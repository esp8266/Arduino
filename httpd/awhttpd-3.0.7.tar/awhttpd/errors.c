/* Anti-Web HTTPD */
/* Hardcore Software */
/*
This software is Copyright (C) 2001-2004 By Hardcore Software and
others. The software is distributed under the terms of the GNU General
Public License. See the file 'COPYING' for more details.
*/


#include <stdio.h>
#include <unistd.h>
#include <string.h>

#include "aw3.h"


void send301(struct connstruct *cn) {

  char buf[2048];

  snprintf(buf, sizeof(buf), "HTTP/1.1 301 Moved Permanently\nLocation: %s/\n\n<!DOCTYPE HTML PUBLIC \"-//IETF//DTD HTML 2.0//EN\">\n<HTML><HEAD>\n<TITLE>301 Moved Permanently</TITLE>\n</HEAD><BODY>\n<H1>Moved Permanently</H1>\nThe document has moved <A HREF=\"%s/\">here</A>.<P>\n<HR>\n</BODY></HTML>\n", cn->filereq, cn->filereq);

  write(cn->networkdesc, buf, strlen(buf));

  return;

}



void send404(struct connstruct *cn) {

  char buf[1024];

  snprintf(buf, sizeof(buf), "HTTP/1.0 404 Not Found\nContent-Type: text/html\n\n<HTML><BODY>\n<TITLE>404 Not Found</TITLE><H1>It ain't there my friend. (404 Not Found)</H1>\n<BR><BR>Anti-Web HTTPD - Take back some simplicity.\n</BODY></HTML>\n");

  write(cn->networkdesc, buf, strlen(buf));

  return;

}



void send505(int sd, char *reason) {

  char buf[1024];

  snprintf(buf, sizeof(buf), "HTTP/1.0 505 Server Error\nContent-Type: text/html\n\n<HTML><BODY>\n<TITLE>505 Internal Server Error</TITLE><H1>Internal Server Error: %s</H1>\n<BR><BR>Anti-Web HTTPD - Take back some simplicity.\n</BODY></HTML>\n", reason);

  write(sd, buf, strlen(buf));

  return;

}
