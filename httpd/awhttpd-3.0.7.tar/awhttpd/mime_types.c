/* Anti-Web HTTPD */
/* Hardcore Software */
/*
This software is Copyright (C) 2001-2004 By Hardcore Software and
others. The software is distributed under the terms of the GNU General
Public License. See the file 'COPYING' for more details.
*/


/*Code from mini_httpd - small HTTP server
**
** Copyright C 1999,2000 by Jef Poskanzer <jef@acme.com>.
*/

/* mini_httpd code adapted for Anti-Web by zas@norz.org */
/* A couple TINY changes by Fractal */

// Reformatted for aw3 -fractal

// FIXME: Ideally this code would use a binary search or a hash table...


#include <string.h>


char mime_default[] = "text/plain";

struct {
  char *ext;
  char *type;
} mime_table[] = {

// Fundamentals
{ ".html", "text/html" },
{ ".htm", "text/html" },
{ ".txt", "text/plain" },

// Others
{ ".rtx", "text/richtext" },
{ ".etx", "text/x-setext" },
{ ".tsv", "text/tab-separated-values" },
{ ".css", "text/css" },
{ ".xml", "text/xml" },
{ ".dtd", "text/xml" },
{ ".gif", "image/gif" },
{ ".jpg", "image/jpeg" },
{ ".jpeg", "image/jpeg" },
{ ".jpe", "image/jpeg" },
{ ".jfif", "image/jpeg" },
{ ".tif", "image/tiff" },
{ ".tiff", "image/tiff" },
{ ".pbm", "image/x-portable-bitmap" },
{ ".pgm", "image/x-portable-graymap" },
{ ".ppm", "image/x-portable-pixmap" },
{ ".pnm", "image/x-portable-anymap" },
{ ".xbm", "image/x-xbitmap" },
{ ".xpm", "image/x-xpixmap" },
{ ".xwd", "image/x-xwindowdump" },
{ ".ief", "image/ief" },
{ ".png", "image/png" },
{ ".au", "audio/basic" },
{ ".snd", "audio/basic" },
{ ".aif", "audio/x-aiff" },
{ ".aiff", "audio/x-aiff" },
{ ".aifc", "audio/x-aiff" },
{ ".ra", "audio/x-pn-realaudio" },
{ ".ram", "audio/x-pn-realaudio" },
{ ".rm", "audio/x-pn-realaudio" },
{ ".rpm", "audio/x-pn-realaudio-plugin" },
{ ".wav", "audio/wav" },
{ ".mid", "audio/midi" },
{ ".midi", "audio/midi" },
{ ".kar", "audio/midi" },
{ ".mpga", "audio/mpeg" },
{ ".mp2", "audio/mpeg" },
{ ".mp3", "audio/mpeg" },
{ ".mpeg", "video/mpeg" },
{ ".mpg", "video/mpeg" },
{ ".mpe", "video/mpeg" },
{ ".qt", "video/quicktime" },
{ ".mov", "video/quicktime" },
{ ".avi", "video/x-msvideo" },
{ ".movie", "video/x-sgi-movie" },
{ ".mv", "video/x-sgi-movie" },
{ ".vx", "video/x-rad-screenplay" },
{ ".a", "application/octet-stream" },
{ ".bin", "application/octet-stream" },
{ ".exe", "application/octet-stream" },
{ ".dump", "application/octet-stream" },
{ ".o", "application/octet-stream" },
{ ".class", "application/java" },
{ ".js", "application/x-javascript" },
{ ".ai", "application/postscript" },
{ ".eps", "application/postscript" },
{ ".ps", "application/postscript" },
{ ".dir", "application/x-director" },
{ ".dcr", "application/x-director" },
{ ".dxr", "application/x-director" },
{ ".fgd", "application/x-director" },
{ ".aam", "application/x-authorware-map" },
{ ".aas", "application/x-authorware-seg" },
{ ".aab", "application/x-authorware-bin" },
{ ".fh4", "image/x-freehand" },
{ ".fh7", "image/x-freehand" },
{ ".fh5", "image/x-freehand" },
{ ".fhc", "image/x-freehand" },
{ ".fh", "image/x-freehand" },
{ ".spl", "application/futuresplash" },
{ ".swf", "application/x-shockwave-flash" },
{ ".dvi", "application/x-dvi" },
{ ".gtar", "application/x-gtar" },
{ ".hdf", "application/x-hdf" },
{ ".hqx", "application/mac-binhex40" },
{ ".iv", "application/x-inventor" },
{ ".latex", "application/x-latex" },
{ ".man", "application/x-troff-man" },
{ ".me", "application/x-troff-me" },
{ ".mif", "application/x-mif" },
{ ".ms", "application/x-troff-ms" },
{ ".oda", "application/oda" },
{ ".pdf", "application/pdf" },
{ ".rtf", "application/rtf" },
{ ".bcpio", "application/x-bcpio" },
{ ".cpio", "application/x-cpio" },
{ ".sv4cpio", "application/x-sv4cpio" },
{ ".sv4crc", "application/x-sv4crc" },
{ ".sh", "application/x-shar" },
{ ".shar", "application/x-shar" },
{ ".sit", "application/x-stuffit" },
{ ".tar", "application/x-tar" },
{ ".tex", "application/x-tex" },
{ ".texi", "application/x-texinfo" },
{ ".texinfo", "application/x-texinfo" },
{ ".tr", "application/x-troff" },
{ ".roff", "application/x-troff" },
{ ".man", "application/x-troff-man" },
{ ".me", "application/x-troff-me" },
{ ".ms", "application/x-troff-ms" },
{ ".zip", "application/x-zip-compressed" },
{ ".tsp", "application/dsptype" },
{ ".wsrc", "application/x-wais-source" },
{ ".ustar", "application/x-ustar" },
{ ".cdf", "application/x-netcdf" },
{ ".nc", "application/x-netcdf" },
{ ".doc", "application/msword" },
{ ".ppt", "application/powerpoint" },
{ ".wrl", "model/vrml" },
{ ".vrml", "model/vrml" },
{ ".mime", "message/rfc822" },
{ ".pac", "application/x-ns-proxy-autoconfig" },
{ ".wml", "text/vnd.wap.wml" },
{ ".wmlc", "application/vnd.wap.wmlc" },
{ ".wmls", "text/vnd.wap.wmlscript" },
{ ".wmlsc", "application/vnd.wap.wmlscriptc" },
{ ".wbmp", "image/vnd.wap.wbmp" },
{ ".tgz", "application/x-gzip" },
{ ".tar.gz", "application/x-gzip" },
{ ".bz2", "application/x-bzip2" },
{ ".zip", "application/zip" }

};


char *getmimetype(char *name) {
  int namelen, extlen, i;

  namelen = strlen(name);

  for (i=0; i<sizeof(mime_table)/sizeof(*mime_table); i++) {
    extlen = strlen(mime_table[i].ext);

    if (extlen >= namelen) continue;

    if (strcasecmp(name+(namelen-extlen), mime_table[i].ext) == 0)
      return mime_table[i].type;
  }

  return mime_default;

}
