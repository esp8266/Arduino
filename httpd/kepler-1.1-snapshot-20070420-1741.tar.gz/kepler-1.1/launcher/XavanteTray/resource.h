//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by XavanteTray.rc
//
#define IDC_MYICON                      2
#define IDD_XAVANTETRAY_DIALOG          102
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDS_HELLO                       106
#define IDI_XAVANTETRAY                 107
#define IDI_XAVANTESTART                108
#define IDC_XAVANTETRAY                 109
#define IDI_XAVANTESTOP                 109
#define IDR_MAINFRAME                   128
#define IDR_POPUP_MENU                  130
#define IDI_ICON1                       130
#define IDI_ICON2                       131
#define IDR_POPUP_CLOSE                 131
#define IDI_ICON3                       132
#define IDI_ICON4                       133
#define IDB_XAVANTELOGO                 134
#define ID_POPUP_OPTION1                32771
#define ID_POPUP_OPTION2                32772
#define ID_POPUP_ANIMATE                32773
#define IDM_ANIMATE                     32773
#define IDM_CYCLE                       32773
#define IDM_SHOWLOG                     32775
#define ID_APP_ABOUT                    0xE140
#define ID_APP_EXIT                     0xE141
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
