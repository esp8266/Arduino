---------------------------------------------------------------------
-- Main Lua script.
-- This script should be run by the executable.
-- $Id: t_cgi.lua,v 1.7 2007/03/12 19:45:41 mascarenhas Exp $
---------------------------------------------------------------------

-- Kepler bootstrap
local bootstrap, err = loadfile(os.getenv("KEPLER_INIT") or "kepler_init.lua") or loadfile([[KEPLER_INIT]])
if bootstrap then
  bootstrap()
else
  io.stderr:write(tostring(err))
  return nil
end

local info = require"sapi.cgi.info"
local req = require"sapi.cgi.request"
local res = require"sapi.cgi.response"
SAPI = {
	Info = info.open (),
	Request = req.open (),
	Response = res.open (),
}

require"cgilua"
return cgilua.main()
