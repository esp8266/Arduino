#ifdef MAINSCRIPT
#define DEFAULT_MAINSCRIPT MAINSCRIPT
#else
#define DEFAULT_MAINSCRIPT "/usr/local/share/lua/5.0/cgilua/mod2.lua"
#endif
#define REQUEST_RECORD     "RequestRecord"
#define MODULE_ERROR_NAME  "mod_lua: "
